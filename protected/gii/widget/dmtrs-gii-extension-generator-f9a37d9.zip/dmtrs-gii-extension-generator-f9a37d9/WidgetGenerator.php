<?php
class WidgetGenerator extends CCodeGenerator
{
    public $codeModel = 'application.gii.widget.WidgetCode';
}
